package ru.sapteh;


import java.io.*;
import java.net.URL;
import java.nio.file.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
        String sourcePath="C:/test/nio";
        System.out.println("Введите название архива: ");
        String zipArchive=reader.readLine();
        System.out.println("Введите название копируемого файла: ");
        String fileName=reader.readLine();
        System.out.println("Введите url картинки: ");
        String nameUrl=reader.readLine();
        System.out.println("Введите название картинки: ");
        String picture=reader.readLine();
        FileOutputStream pathArchive=new FileOutputStream(sourcePath + File.separator+zipArchive);
        ZipOutputStream zip=new ZipOutputStream(pathArchive);
        zip.putNextEntry(new ZipEntry("tests.txt"));
        Path file= Paths.get(sourcePath + File.separator + fileName);
        Files.copy(file,zip);


        URL url=new URL(nameUrl);
        InputStream stream=url.openStream();
        Path pathPicture=Paths.get(sourcePath+File.separator+picture);
        Files.copy(stream,pathPicture,StandardCopyOption.REPLACE_EXISTING);
        zip.putNextEntry(new ZipEntry(picture));
        Files.copy(pathPicture,zip);
        Files.delete(pathPicture);
        stream.close();
        zip.close();

    }
}
