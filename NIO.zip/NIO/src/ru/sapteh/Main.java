package ru.sapteh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Введите название директории: ");
        String dirName= reader.readLine();

        System.out.println("Введите названия файла: ");
        String fileName=reader.readLine();

        System.out.println("Введите ключевую фразу: ");
        String word=reader.readLine();

        Path sourceDir=Paths.get("c:/test/nio");
        Path dir=Paths.get(sourceDir.resolve(dirName).toString());
        if (!Files.exists(dir)){
            Files.createDirectory(dir);
            System.out.printf("Directory %s created \n",dir.getFileName());
        }else System.out.printf("Директория %s уже создана \n", dir.getFileName());
        Path file =Paths.get(sourceDir.resolve(fileName).toString());
        if (!Files.exists(file)){
            Files.createFile(file);
            System.out.printf("Файл %s создан \n",file.getFileName());
        }else System.out.printf("Файл %s уже был создан \n", file.getFileName());

        MyFileVisitor myFileVisitor=new MyFileVisitor();
        myFileVisitor.setWord(word);
        Files.walkFileTree(sourceDir,myFileVisitor);
        System.out.println(myFileVisitor.getCountDir());
        System.out.println(myFileVisitor.getCountFile());
        System.out.printf("%.3f КБ",myFileVisitor.getSizeDir()/1024F);
    }
}
