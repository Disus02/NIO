package ru.sapteh;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.List;
import java.util.Set;

public class MyFileVisitor extends SimpleFileVisitor<Path> {
    private int countFile;
    private int countDir;
    private long sizeDir;
    private String word;

    public int getCountFile(){
        return countFile;
    }

    public int getCountDir() {
        return countDir;
    }

    public long getSizeDir() {
        return sizeDir;
    }

    public void setWord(String word) {
        this.word = word;
    }

    @Override
    public FileVisitResult preVisitDirectory(Path file, BasicFileAttributes attr) {
        countDir++;
        return FileVisitResult.CONTINUE;
    }
    @Override
    public FileVisitResult visitFile(Path file, BasicFileAttributes attr) throws IOException {
        List<String> lines= Files.readAllLines(file);
        System.out.println(lines);
        for (String str: lines){
            if (str.contains(word)){
                System.out.printf("Файл в котором находится ключевое слово: %s \n",file.toAbsolutePath());
            }
        }
        sizeDir+=attr.size();
        countFile++;
        return FileVisitResult.CONTINUE;
    }
}
